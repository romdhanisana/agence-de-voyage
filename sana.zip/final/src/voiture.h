#ifndef VOITURE_H_
#define VOITURE_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_voiture
{
int jour;
int mois;
int annee;
}datev;

typedef struct
{ 
char ref_voit[20];
datev dtvo;
char marque[20];
char matricule[20];
char duree;
char prix[20];

}voiture;

void ajouter_voiture(voiture *v); 

void afficher_tout_voiture(GtkWidget *liste);

void afficher_reser_voiture(GtkWidget *liste);

void afficher_rech_voiture(GtkWidget *liste);

void supprimer_voiture(char *reference);

void reserver_voiture(char *reference);

void chercher_voiture(char *marque );


#endif
