#include "hotel.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 REF,
 PAYS,
 NOM,
 DATE,
 DUREE,
 PRIX,
 ETOILE,
 COLUMNS
};

void ajouter_hotel(hotel *h)
{/*
FILE *f;
f=fopen("toutvol.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
char r1[20];
char r2[20];
char r3[20];
char dt_aller[20]="";

sprintf(r1,"%d",v->dtv.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",v->dtv.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",v->dtv.annee);
strcat(dt_aller,r3);


fprintf(f,"%s %s %s %s %s %s %s \n",v->ref_vol,v->depart,v->arrivee,dt_aller,v->duree,v->classe,v->prix);
fclose(f); //fermeture du fichier
} */
}

void afficher_tout_hotel(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char pays[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference hotel", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Pays ", renderer,"text",PAYS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Nom ", renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Nombre etoiles", renderer,"text",ETOILE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("touthotel.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,pays,nom,etoile,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,PAYS,pays,NOM,nom,ETOILE,etoile,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_rech_hotel(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char pays[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];



store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference hotel", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Pays ", renderer,"text",PAYS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Nom ", renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Nombre etoiles", renderer,"text",ETOILE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("resultathotel.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,pays,nom,etoile,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,PAYS,pays,NOM,nom,ETOILE,etoile,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_reser_hotel(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char pays[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference hotel", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Pays ", renderer,"text",PAYS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Nom ", renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Nombre etoiles", renderer,"text",ETOILE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("reservationhotel.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,pays,nom,etoile,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,PAYS,pays,NOM,nom,ETOILE,etoile,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

/*********Supp vol***************/
void supprimer_hotel(char *reference)
{

char ref[20];
char pays[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];


FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("hotel_test.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("reservationhotel.txt","r");
new=fopen("hotel_test.txt","a+");
/**************************/

while (fscanf(old,"%s %s %s %s %s %s %s \n",ref,pays,nom,etoile,date,duree,prix)!=EOF)

	{
	if(strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",ref,pays,nom,etoile,date,duree,prix);
		}
	}
fclose(new);
fclose(old);
remove("reservationhotel.txt");//nfas5ou il fichier li9dim
rename("hotel_test.txt","reservationhotel.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}
void chercher_hotel(char *pays/*,char *arrivee ,char *date ,char *classe*/)
{

char reference[20];
char pys[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];

FILE *old;
FILE *new;
/*****create a temporary file *****/
new=fopen("resultathotel.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("touthotel.txt","r");
new=fopen("resultathotel.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s %s \n",reference,pys,nom,etoile,date,duree,prix)!=EOF)

	{
	if(!strcmp(pys,pays))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",reference,pys,nom,etoile,date,duree,prix);
		}
	}



fclose(new);
fclose(old);


}

void reserver_hotel(char *reference)
{
char ref[20];
char pays[20];
char nom[20];
char etoile[20];
char date[20];
char duree[20];
char prix[20];

FILE *old;
FILE *new=NULL;

/******copy data from old to new *******/
old=fopen("touthotel.txt","r");
new=fopen("reservationhotel.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s %s \n",ref,pays,nom,etoile,date,duree,prix)!=EOF)
	{
	if(!strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",ref,pays,nom,etoile,date,duree,prix);
		}
	}
fclose(new);
fclose(old);

}




