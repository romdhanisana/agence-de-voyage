#ifndef HOTEL_H_
#define HOTEL_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_hotel
{
int jour;
int mois;
int annee;
}dateh;

typedef struct
{ 
char ref_hotel[20];
dateh dth;
char pays[20];
char nom[20];
char etoile;
char duree;
char prix[20];

}hotel;

void ajouter_hotel(hotel *h); 

void afficher_tout_hotel(GtkWidget *liste);

void afficher_reser_hotel(GtkWidget *liste);

void afficher_rech_hotel(GtkWidget *liste);

void supprimer_hotel(char *reference);

void reserver_hotel(char *reference);

void chercher_hotel(char *pays /*,char *arrivee,char *date,char *classe */);


#endif
