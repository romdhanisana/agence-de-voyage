#include <gtk/gtk.h>


void
on_button_remplir_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_espace_client_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_quitter0_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplissage_vol_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_remplissage_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplir_vol_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_remplissagevol_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_menu_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_menu_client_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_rech_vol_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_rech_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_reser_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_rech_vol_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_reser_vol_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retour_affich_vol_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supp_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modif_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affich_vol_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_fenetre_vol_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplissage_hotel_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplir_hotel_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
on_button_retour_remplissagevol_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);
*/
void
on_button_menu_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_rech_hotel_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retour_rech_hotel_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_reser_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rech_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_reser_hotel_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modif_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supp_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_affich_hotel_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affich_hotel_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_fenetre_hotel_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_remplissagehotel_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplissage_voiture_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_remplir_voiture_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_remplissagevoit_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affich_voiture_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_fenetre_voiture_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_rech_voiture_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_reser_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_rech_voiture_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rech_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_reser_voiture_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_supp_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modif_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_affich_voiture_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_menu_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closebutton2_activate               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closebutton3_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
