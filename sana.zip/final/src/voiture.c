#include "voiture.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 REF,
 MARQUE,
 MATRICULE,
 DATE,
 DUREE,
 PRIX,
 COLUMNS
};

void ajouter_voiture(voiture *v)
{
FILE *f;
f=fopen("toutvoiture.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
char r1[20];
char r2[20];
char r3[20];
char dt[20]="";

sprintf(r1,"%d",v->dtvo.jour);
strcat(dt,r1);
strcat(dt,"/");

sprintf(r2,"%d",v->dtvo.mois);
strcat(dt,r2);
strcat(dt,"/");

sprintf(r3,"%d",v->dtvo.annee);
strcat(dt,r3);


fprintf(f,"%s %s %s %s %s %s \n",v->ref_voit,v->marque,v->matricule,dt,v->duree,v->prix);
fclose(f); //fermeture du fichier
} 
}

void afficher_tout_voiture(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char marque[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference voiture", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Marque ", renderer,"text",MARQUE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Matricule ", renderer,"text",MATRICULE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date de reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("toutvoiture.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s \n",reference,marque,matricule,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,MARQUE,marque,MATRICULE,matricule,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_rech_voiture(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char marque[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference voiture", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Marque ", renderer,"text",MARQUE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Matricule ", renderer,"text",MATRICULE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date de reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("resultatvoiture.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s \n",reference,marque,matricule,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,MARQUE,marque,MATRICULE,matricule,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_reser_voiture(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char marque[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference voiture", renderer,"text",REF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Marque ", renderer,"text",MARQUE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Matricule ", renderer,"text",MATRICULE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date de reservation", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/j", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("reservationvoiture.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s \n",reference,marque,matricule,date,duree,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,REF,reference,MARQUE,marque,MATRICULE,matricule,DATE,date,DUREE,duree,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

/*********Supp vol***************/
void supprimer_voiture(char *reference)
{

char ref[20];
char marque[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];


FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("voiture_test.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("reservationvoiture.txt","r");
new=fopen("voiture_test.txt","a+");
/**************************/

while (fscanf(old,"%s %s %s %s %s %s \n",ref,marque,matricule,date,duree,prix)!=EOF)

	{
	if(strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s \n",ref,marque,matricule,date,duree,prix);
		}
	}
fclose(new);
fclose(old);
remove("reservationvoiture.txt");//nfas5ou il fichier li9dim
rename("voiture_test.txt","reservationvoiture.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}
void chercher_voiture(char *marque/*,char *arrivee ,char *date ,char *classe*/)
{

char reference[20];
char marq[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];


FILE *old;
FILE *new;
/*****create a temporary file *****/
new=fopen("resultatvoiture.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("toutvoiture.txt","r");
new=fopen("resultatvoiture.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s \n",reference,marq,matricule,date,duree,prix)!=EOF)

	{
	if(!strcmp(marq,marque))
		{	
		fprintf(new,"%s %s %s %s %s %s \n",reference,marq,matricule,date,duree,prix);
		}
	}



fclose(new);
fclose(old);


}

void reserver_voiture(char *reference)
{
char ref[20];
char marque[20];
char matricule[20];
char date[20];
char duree[20];
char prix[20];


FILE *old;
FILE *new=NULL;

/******copy data from old to new *******/
old=fopen("toutvoiture.txt","r");
new=fopen("reservationvoiture.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s \n",ref,marque,matricule,date,duree,prix)!=EOF)
	{
	if(!strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s \n",ref,marque,matricule,date,duree,prix);
		}
	}
fclose(new);
fclose(old);

}

