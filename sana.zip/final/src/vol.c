#include "vol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 VLREF,
 DEPART,
 ARRIVEE,
 DATEA,
 DUREE,
 CLASSE,
 PRIX,
 COLUMNS
};

void ajouter_vol(vol *v)
{
FILE *f;
f=fopen("toutvol.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
char r1[20];
char r2[20];
char r3[20];
char dt_aller[20]="";

sprintf(r1,"%d",v->dtv.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",v->dtv.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",v->dtv.annee);
strcat(dt_aller,r3);


fprintf(f,"%s %s %s %s %s %s %s \n",v->ref_vol,v->depart,v->arrivee,dt_aller,v->duree,v->classe,v->prix);
fclose(f); //fermeture du fichier
} 
}

void afficher_tout_vol(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char depart[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference vol", renderer,"text",VLREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Depart ", renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Arrivée ", renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date d'aller", renderer,"text",DATEA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/h", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Classe", renderer,"text",CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("toutvol.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,depart,arrivee,date,duree,classe,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,VLREF,reference,DEPART,depart,ARRIVEE,arrivee,DATEA,date,DUREE,duree,CLASSE,classe,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_rech_vol(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char depart[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference vol", renderer,"text",VLREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Depart ", renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Arrivée ", renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date d'aller", renderer,"text",DATEA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/h", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Classe", renderer,"text",CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("resultatvol.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,depart,arrivee,date,duree,classe,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,VLREF,reference,DEPART,depart,ARRIVEE,arrivee,DATEA,date,DUREE,duree,CLASSE,classe,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficher_reser_vol(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char reference[20];
char depart[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reference vol", renderer,"text",VLREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Depart ", renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Arrivée ", renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date d'aller", renderer,"text",DATEA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" durée/h", renderer,"text",DUREE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Classe", renderer,"text",CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prix/€", renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("reservationvol.txt","r"); 
if(f!=NULL) 
{
while (fscanf(f,"%s %s %s %s %s %s %s \n",reference,depart,arrivee,date,duree,classe,prix)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,VLREF,reference,DEPART,depart,ARRIVEE,arrivee,DATEA,date,DUREE,duree,CLASSE,classe,PRIX,prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

/*********Supp vol***************/
void supprimer_vol(char *reference)
{

char ref[20];
char depart[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];


FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("vol_test.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("reservationvol.txt","r");
new=fopen("vol_test.txt","a+");
/**************************/

while (fscanf(old,"%s %s %s %s %s %s %s \n",ref,depart,arrivee,date,duree,classe,prix)!=EOF)

	{
	if(strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",ref,depart,arrivee,date,duree,classe,prix);
		}
	}
fclose(new);
fclose(old);
remove("reservationvol.txt");//nfas5ou il fichier li9dim
rename("vol_test.txt","reservationvol.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}
void chercher_vol(char *depart/*,char *arrivee ,char *date ,char *classe*/)
{

char ref[20];
char dep[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];


FILE *old;
FILE *new;
/*****create a temporary file *****/
new=fopen("resultatvol.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("toutvol.txt","r");
new=fopen("resultatvol.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s %s \n",ref,dep,arrivee,date,duree,classe,prix)!=EOF)

	{
	if(!strcmp(dep,depart))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",ref,dep,arrivee,date,duree,classe,prix);
		}
	}



fclose(new);
fclose(old);


}

void reserver_vol(char *reference)
{
char ref[20];
char depart[20];
char arrivee[20];
char date[20];
char duree[20];
char classe[20];
char prix[20];

FILE *old;
FILE *new=NULL;

/******copy data from old to new *******/
old=fopen("toutvol.txt","r");
new=fopen("reservationvol.txt","a+");
/**************************/
while (fscanf(old,"%s %s %s %s %s %s %s \n",ref,depart,arrivee,date,duree,classe,prix)!=EOF)
	{
	if(!strcmp(ref,reference))
		{	
		fprintf(new,"%s %s %s %s %s %s %s \n",ref,depart,arrivee,date,duree,classe,prix);
		}
	}
fclose(new);
fclose(old);

}

