#ifndef VOL_H_
#define VOL_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_vol
{
int jour;
int mois;
int annee;
}date;

typedef struct
{ 
char ref_vol[20];
date dtv;
char depart[20];
char arrivee[20];
char duree[20];
char classe[20];
char prix[20];

}vol;

void ajouter_vol(vol *v); 

void afficher_tout_vol(GtkWidget *liste);

void afficher_reser_vol(GtkWidget *liste);

void afficher_rech_vol(GtkWidget *liste);

void supprimer_vol(char *reference);

void reserver_vol(char *reference);

void chercher_vol(char *depart/*,char *arrivee,char *date,char *classe*/ );


#endif
