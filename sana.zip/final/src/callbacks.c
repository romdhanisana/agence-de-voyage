#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "vol.h"
#include "hotel.h"
#include "voiture.h"

int p;
vol x,v1,v2;
hotel h,h1,h2;
voiture y,vo1,vo2;
void
on_button_remplir_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1, *menu_remplissage;

window1=lookup_widget(GTK_WIDGET(objet),("window1"));

menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(window1);
menu_remplissage=create_menu_remplissage();
gtk_widget_show(menu_remplissage);
}


void
on_button_espace_client_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1, *menu_client;

window1=lookup_widget(GTK_WIDGET(objet),("window1"));
menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));

gtk_widget_destroy(window1);
menu_client=create_menu_client();
gtk_widget_show(menu_client);
}


void
on_button_quitter0_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
gtk_main_quit() ;
}


void
on_button_remplissage_vol_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{/***********/
GtkWidget *remplissage_vol, *menu_remplissage;

remplissage_vol=lookup_widget(GTK_WIDGET(objet),("remplissage_vol"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(menu_remplissage);
remplissage_vol=create_remplissage_vol();
gtk_widget_show(remplissage_vol);
}


void
on_button_retour_remplissage_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1, *menu_remplissage;

window1=lookup_widget(GTK_WIDGET(objet),("window1"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(menu_remplissage);
window1=create_window1();
gtk_widget_show(window1);
}


void
on_button_remplir_vol_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
vol x;
GtkWidget *depart=lookup_widget(GTK_WIDGET(objet),"entry_depart");
GtkWidget *arrivee=lookup_widget(GTK_WIDGET(objet),"entry_arrivee");
GtkWidget *reference=lookup_widget(GTK_WIDGET(objet),"entry_v_reference");
GtkWidget *prix=lookup_widget(GTK_WIDGET(objet),"entry_v_prix");

GtkWidget *duree=lookup_widget(GTK_WIDGET(objet),"r_v_d");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(objet),"r_v_j");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(objet),"r_v_a");
GtkWidget *an1=lookup_widget(GTK_WIDGET(objet),"r_v_m");

GtkWidget *classe=lookup_widget(GTK_WIDGET(objet),"comb_remplir_v_c");
/*
if((strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prenom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(cin))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mail))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(tel))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tache)),"")==0))
{ 
g_print("non");
GtkWidget *dialog4;
dialog4=create_dialog4() ;
gtk_widget_show(dialog4) ;

}
else if (strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),(gtk_entry_get_text(GTK_ENTRY(mdp2)))) != 0)
{ 
g_print("non");
GtkWidget *dialog5;
dialog5=create_dialog5() ;
gtk_widget_show(dialog5) ;
}

else{*/
strcpy(x.depart,gtk_entry_get_text(GTK_ENTRY(depart)));
strcpy(x.arrivee,gtk_entry_get_text(GTK_ENTRY(arrivee)));
strcpy(x.ref_vol,gtk_entry_get_text(GTK_ENTRY(reference)));
strcpy(x.prix,gtk_entry_get_text(GTK_ENTRY(prix)));


strcpy(x.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));

x.dtv.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
x.dtv.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
x.dtv.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));
p= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(duree));
sprintf(x.duree,"%d",p);
/*
GtkWidget *dialog3;
dialog3=create_dialog3() ;
gtk_widget_show(dialog3) ;
*/
ajouter_vol(&x);
//}
}

/***************************************ttttttttttttttttttttt*/////////////////
void
on_button_retour_remplissagevol_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *remplissage_vol, *menu_remplissage;

remplissage_vol=lookup_widget(GTK_WIDGET(objet),("remplissage_vol"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(remplissage_vol);
menu_remplissage=create_menu_remplissage();
gtk_widget_show(menu_remplissage);
}


void
on_button_menu_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_vol;

menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));
fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));

gtk_widget_destroy(menu_client);
fenetre_vol=create_fenetre_vol();
gtk_widget_show(fenetre_vol);
}


void
on_button_retour_menu_client_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *window1;

menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));
window1=lookup_widget(GTK_WIDGET(objet),("window1"));

gtk_widget_destroy(menu_client);
window1=create_window1();
gtk_widget_show(window1);
}


void
on_treeview_rech_vol_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(v1.ref_vol,str_data);
}


void
on_button_rech_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
vol c;
GtkWidget *jr=lookup_widget(GTK_WIDGET(objet),"spin_vol_j");
GtkWidget *ms=lookup_widget(GTK_WIDGET(objet),"spin_vol_m");
GtkWidget *an=lookup_widget(GTK_WIDGET(objet),"spin_vol_a");


GtkWidget *combobox_classe_vol=lookup_widget(GTK_WIDGET(objet),"combo_classe_vol");
GtkWidget *combobox_depart_vol=lookup_widget(GTK_WIDGET(objet),"combo_depart_vol");
GtkWidget *combobox_arr_vol=lookup_widget(GTK_WIDGET(objet),"combo_arrivee_vol");


c.dtv.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
c.dtv.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
c.dtv.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

strcpy(c.depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_depart_vol)));
strcpy(c.arrivee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_arr_vol)));
strcpy(c.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_classe_vol)));


char r1[20];
char r2[20];
char r3[20];
char dt_aller[20]="";


sprintf(r1,"%d",c.dtv.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",c.dtv.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",c.dtv.annee);
strcat(dt_aller,r3);

chercher_vol((char *)c.depart/*,(char *)c.arrivee,(char *)dt_aller,(char *)c.classe*/ );

GtkWidget *rech_vol=lookup_widget(GTK_WIDGET(objet),"rech_vol");
GtkWidget *treeview_rech_vol;

treeview_rech_vol=lookup_widget(rech_vol,"treeview_rech_vol");

afficher_rech_vol(treeview_rech_vol);
gtk_widget_show(treeview_rech_vol);
}


void
on_button_reser_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification1;
Notification1=lookup_widget(GTK_WIDGET(objet),("Notification1"));
Notification1=create_Notification1();
gtk_widget_show(Notification1);
reserver_vol((char*)v1.ref_vol);

}


void
on_button_retour_rech_vol_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_vol, *fenetre_vol;

fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));
rech_vol=lookup_widget(GTK_WIDGET(objet),("rech_vol"));

gtk_widget_destroy(rech_vol);
fenetre_vol=create_fenetre_vol();
gtk_widget_show(fenetre_vol);

}


void
on_treeview_reser_vol_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(v2.ref_vol,str_data);
}


void
on_button_retour_affich_vol_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_vol, *fenetre_vol;

fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));
affich_reser_vol=lookup_widget(GTK_WIDGET(objet),("affich_reser_vol"));

gtk_widget_destroy(affich_reser_vol);
fenetre_vol=create_fenetre_vol();
gtk_widget_show(fenetre_vol);

}


void
on_button_supp_vol_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

supprimer_vol((char *)v2.ref_vol);
/*****Actualiser lil liste **************/
GtkWidget *affich_reser_vol=lookup_widget(GTK_WIDGET(objet),"affich_reser_vol");
GtkWidget *treeview_reser_vol;

treeview_reser_vol=lookup_widget(affich_reser_vol,"treeview_reser_vol");

afficher_reser_vol(treeview_reser_vol);
gtk_widget_show(treeview_reser_vol);


GtkWidget *Notification3;
Notification3=lookup_widget(GTK_WIDGET(objet),("Notification3"));
Notification3=create_Notification3();
gtk_widget_show(Notification3);
}


void
on_button_modif_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
supprimer_vol((char *)v2.ref_vol);

GtkWidget *affich_reser_vol, *rech_vol;

rech_vol=lookup_widget(GTK_WIDGET(objet),("rech_vol"));
affich_reser_vol=lookup_widget(GTK_WIDGET(objet),("affich_reser_vol"));

gtk_widget_destroy(affich_reser_vol);
rech_vol=create_rech_vol();
gtk_widget_show(rech_vol);
}


void
on_button_affich_vol_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_vol, *fenetre_vol;

fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));
affich_reser_vol=lookup_widget(GTK_WIDGET(objet),("affich_reser_vol"));

gtk_widget_destroy(fenetre_vol);
affich_reser_vol=create_affich_reser_vol();
gtk_widget_show(affich_reser_vol);

/*******0000000000000************/

GtkWidget *treeview_reser_vol;

treeview_reser_vol=lookup_widget(affich_reser_vol,"treeview_reser_vol");

afficher_reser_vol(treeview_reser_vol);
gtk_widget_show(treeview_reser_vol);
}


void
on_button_ajout_vol_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_vol, *fenetre_vol;

fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));
rech_vol=lookup_widget(GTK_WIDGET(objet),("rech_vol"));

gtk_widget_destroy(fenetre_vol);
rech_vol=create_rech_vol();
gtk_widget_show(rech_vol);

/******000000************/
GtkWidget *treeview_rech_vol;

treeview_rech_vol=lookup_widget(rech_vol,"treeview_rech_vol");

afficher_tout_vol(treeview_rech_vol);
gtk_widget_show(treeview_rech_vol);
}


void
on_button_retour_fenetre_vol_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_vol;

fenetre_vol=lookup_widget(GTK_WIDGET(objet),("fenetre_vol"));
menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));

gtk_widget_destroy(fenetre_vol);
menu_client=create_menu_client();
gtk_widget_show(menu_client);
}


void
on_button_remplissage_hotel_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *remplissage_hotel, *menu_remplissage;

remplissage_hotel=lookup_widget(GTK_WIDGET(objet),("remplissage_hotel"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(menu_remplissage);
remplissage_hotel=create_remplissage_hotel();
gtk_widget_show(remplissage_hotel);
}


void
on_button_remplir_hotel_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
hotel h;
GtkWidget *pays=lookup_widget(GTK_WIDGET(objet),"entry_h_pays");
GtkWidget *nom=lookup_widget(GTK_WIDGET(objet),"entry_h_nom");
GtkWidget *refr=lookup_widget(GTK_WIDGET(objet),"entry_h_refr");
GtkWidget *prix2=lookup_widget(GTK_WIDGET(objet),"entry_h_prix");

GtkWidget *duree2=lookup_widget(GTK_WIDGET(objet),"r_h_d");
GtkWidget *jr2=lookup_widget(GTK_WIDGET(objet),"r_h_j");
GtkWidget *ms2=lookup_widget(GTK_WIDGET(objet),"r_h_m");
GtkWidget *an2=lookup_widget(GTK_WIDGET(objet),"r_h_a");
GtkWidget *etoile=lookup_widget(GTK_WIDGET(objet),"r_h_e");


/*
if((strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prenom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(cin))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mail))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(tel))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tache)),"")==0))
{ 
g_print("non");
GtkWidget *dialog4;
dialog4=create_dialog4() ;
gtk_widget_show(dialog4) ;

}
else if (strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),(gtk_entry_get_text(GTK_ENTRY(mdp2)))) != 0)
{ 
g_print("non");
GtkWidget *dialog5;
dialog5=create_dialog5() ;
gtk_widget_show(dialog5) ;
}

else{*/
strcpy(h.pays,gtk_entry_get_text(GTK_ENTRY(pays)));
strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(h.ref_hotel,gtk_entry_get_text(GTK_ENTRY(refr)));
strcpy(h.prix,gtk_entry_get_text(GTK_ENTRY(prix2)));

h.dth.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr2));
h.dth.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms2));
h.dth.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an2));
h.duree= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(duree2));
h.etoile= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etoile));
/*
GtkWidget *dialog3;
dialog3=create_dialog3() ;
gtk_widget_show(dialog3) ;
*/
ajouter_hotel(&h);
//}
}

/*
void
on_button_retour_remplissagevol_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
ELIMINATEEEEE
}

*/
void
on_button_menu_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_hotel;

menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));
fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));

gtk_widget_destroy(menu_client);
fenetre_hotel=create_fenetre_hotel();
gtk_widget_show(fenetre_hotel);
}


void
on_treeview_rech_hotel_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(h1.ref_hotel,str_data);
}


void
on_button_retour_rech_hotel_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_hotel, *fenetre_hotel;

fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));
rech_hotel=lookup_widget(GTK_WIDGET(objet),("rech_hotel"));

gtk_widget_destroy(rech_hotel);
fenetre_hotel=create_fenetre_hotel();
gtk_widget_show(fenetre_hotel);
}


void
on_button_reser_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification1;
Notification1=lookup_widget(GTK_WIDGET(objet),("Notification1"));
Notification1=create_Notification1();
gtk_widget_show(Notification1);
reserver_hotel((char*)h1.ref_hotel);
}


void
on_button_rech_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
hotel r;
GtkWidget *jr=lookup_widget(GTK_WIDGET(objet),"spin_hotel_j");
GtkWidget *ms=lookup_widget(GTK_WIDGET(objet),"spin_hotel_m");
GtkWidget *an=lookup_widget(GTK_WIDGET(objet),"spin_hotel_a");
GtkWidget *et=lookup_widget(GTK_WIDGET(objet),"spin_hotel_etoile");


GtkWidget *combobox_pays_hotel=lookup_widget(GTK_WIDGET(objet),"combo_pays_hotel");
GtkWidget *combobox_nom_hotel=lookup_widget(GTK_WIDGET(objet),"combo_nom_hotel");



r.dth.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
r.dth.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
r.dth.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

strcpy(r.pays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_pays_hotel)));
strcpy(r.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_nom_hotel)));



char r1[20];
char r2[20];
char r3[20];
char dt_h[20]="";


sprintf(r1,"%d",r.dth.jour);
strcat(dt_h,r1);
strcat(dt_h,"/");

sprintf(r2,"%d",r.dth.mois);
strcat(dt_h,r2);
strcat(dt_h,"/");

sprintf(r3,"%d",r.dth.annee);
strcat(dt_h,r3);

chercher_hotel((char *)r.pays/*,(char *)c.arrivee,(char *)dt_aller,(char *)c.classe*/ );

GtkWidget *rech_hotel=lookup_widget(GTK_WIDGET(objet),"rech_hotel");
GtkWidget *treeview_rech_hotel;

treeview_rech_hotel=lookup_widget(rech_hotel,"treeview_rech_hotel");

afficher_rech_hotel(treeview_rech_hotel);
gtk_widget_show(treeview_rech_hotel);


}


void
on_treeview_reser_hotel_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(h2.ref_hotel,str_data);
}


void
on_button_modif_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
supprimer_hotel((char *)h2.ref_hotel);

GtkWidget *affich_reser_hotel, *rech_hotel;

rech_hotel=lookup_widget(GTK_WIDGET(objet),("rech_hotel"));
affich_reser_hotel=lookup_widget(GTK_WIDGET(objet),("affich_reser_hotel"));

gtk_widget_destroy(affich_reser_hotel);
rech_hotel=create_rech_hotel();
gtk_widget_show(rech_hotel);
}


void
on_button_supp_hotel_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
supprimer_hotel((char *)h2.ref_hotel);
/*****Actualiser lil liste **************/
GtkWidget *affich_reser_hotel=lookup_widget(GTK_WIDGET(objet),"affich_reser_hotel");
GtkWidget *treeview_reser_hotel;

treeview_reser_hotel=lookup_widget(affich_reser_hotel,"treeview_reser_hotel");

afficher_reser_hotel(treeview_reser_hotel);
gtk_widget_show(treeview_reser_hotel);

GtkWidget *Notification3;
Notification3=lookup_widget(GTK_WIDGET(objet),("Notification3"));
Notification3=create_Notification3();
gtk_widget_show(Notification3);
}


void
on_button_retour_affich_hotel_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_hotel, *fenetre_hotel;

fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));
affich_reser_hotel=lookup_widget(GTK_WIDGET(objet),("affich_reser_hotel"));

gtk_widget_destroy(affich_reser_hotel);
fenetre_hotel=create_fenetre_hotel();
gtk_widget_show(fenetre_hotel);
}


void
on_button_affich_hotel_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_hotel, *fenetre_hotel;

fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));
affich_reser_hotel=lookup_widget(GTK_WIDGET(objet),("affich_reser_hotel"));

gtk_widget_destroy(fenetre_hotel);
affich_reser_hotel=create_affich_reser_hotel();
gtk_widget_show(affich_reser_hotel);

/*******0000000000000************/

GtkWidget *treeview_reser_hotel;

treeview_reser_hotel=lookup_widget(affich_reser_hotel,"treeview_reser_hotel");

afficher_reser_hotel(treeview_reser_hotel);
gtk_widget_show(treeview_reser_hotel);
}


void
on_button_ajout_hotel_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_hotel, *fenetre_hotel;

fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));
rech_hotel=lookup_widget(GTK_WIDGET(objet),("rech_hotel"));

gtk_widget_destroy(fenetre_hotel);
rech_hotel=create_rech_hotel();
gtk_widget_show(rech_hotel);

/******000000************/
GtkWidget *treeview_rech_hotel;

treeview_rech_hotel=lookup_widget(rech_hotel,"treeview_rech_hotel");

afficher_tout_hotel(treeview_rech_hotel);
gtk_widget_show(treeview_rech_hotel);
}


void
on_button_retour_fenetre_hotel_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_hotel;

fenetre_hotel=lookup_widget(GTK_WIDGET(objet),("fenetre_hotel"));
menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));

gtk_widget_destroy(fenetre_hotel);
menu_client=create_menu_client();
gtk_widget_show(menu_client);
}


void
on_button_retour_remplissagehotel_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *remplissage_hotel, *menu_remplissage;

remplissage_hotel=lookup_widget(GTK_WIDGET(objet),("remplissage_hotel"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(remplissage_hotel);
menu_remplissage=create_menu_remplissage();
gtk_widget_show(menu_remplissage);
}


void
on_button_remplissage_voiture_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *remplissage_voiture, *menu_remplissage;

remplissage_voiture=lookup_widget(GTK_WIDGET(objet),("remplissage_voiture"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(menu_remplissage);
remplissage_voiture=create_remplissage_voiture();
gtk_widget_show(remplissage_voiture);
}


void
on_button_remplir_voiture_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
voiture y;
GtkWidget *marque=lookup_widget(GTK_WIDGET(objet),"entry_marque");
GtkWidget *matricule=lookup_widget(GTK_WIDGET(objet),"entry_matricule");
GtkWidget *reference=lookup_widget(GTK_WIDGET(objet),"entry_vo_ref");
GtkWidget *prix=lookup_widget(GTK_WIDGET(objet),"entry_vo_prix");

GtkWidget *duree=lookup_widget(GTK_WIDGET(objet),"spin_vo_d");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(objet),"spin_vo_j");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(objet),"spin_vo_m");
GtkWidget *an1=lookup_widget(GTK_WIDGET(objet),"spin_vo_a");


strcpy(y.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(y.matricule,gtk_entry_get_text(GTK_ENTRY(matricule)));
strcpy(y.ref_voit,gtk_entry_get_text(GTK_ENTRY(reference)));
strcpy(y.prix,gtk_entry_get_text(GTK_ENTRY(prix)));


y.dtvo.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
y.dtvo.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
y.dtvo.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));
y.duree= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(duree));

ajouter_voiture(&y);

}


void
on_button_retour_remplissagevoit_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *remplissage_voiture, *menu_remplissage;

remplissage_voiture=lookup_widget(GTK_WIDGET(objet),("remplissage_voiture"));
menu_remplissage=lookup_widget(GTK_WIDGET(objet),("menu_remplissage"));

gtk_widget_destroy(remplissage_voiture);
menu_remplissage=create_menu_remplissage();
gtk_widget_show(menu_remplissage);
}


void
on_button_ajout_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_voiture, *fenetre_voiture;

fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));
rech_voiture=lookup_widget(GTK_WIDGET(objet),("rech_voiture"));

gtk_widget_destroy(fenetre_voiture);
rech_voiture=create_rech_voiture();
gtk_widget_show(rech_voiture);

/******000000************/
GtkWidget *treeview_rech_voiture;

treeview_rech_voiture=lookup_widget(rech_voiture,"treeview_rech_voiture");

afficher_tout_voiture(treeview_rech_voiture);
gtk_widget_show(treeview_rech_voiture);
}


void
on_button_affich_voiture_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_voiture, *fenetre_voiture ,*treeview_reser_voiture;

fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));
affich_reser_voiture=lookup_widget(GTK_WIDGET(objet),("affich_reser_voiture"));

gtk_widget_destroy(fenetre_voiture);
affich_reser_voiture=create_affich_reser_voiture();
gtk_widget_show(affich_reser_voiture);

/*******0000000000000************/

GtkWidget *treeview_reser_vol;

treeview_reser_voiture=lookup_widget(affich_reser_voiture,"treeview_reser_voiture");

afficher_reser_voiture(treeview_reser_voiture);
gtk_widget_show(treeview_reser_voiture);

}


void
on_button_retour_fenetre_voiture_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_voiture;

fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));
menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));

gtk_widget_destroy(fenetre_voiture);
menu_client=create_menu_client();
gtk_widget_show(menu_client);
}


void
on_treeview_rech_voiture_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(vo1.ref_voit,str_data);
}


void
on_button_reser_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification1;
Notification1=lookup_widget(GTK_WIDGET(objet),("Notification1"));
Notification1=create_Notification1();
gtk_widget_show(Notification1);
reserver_voiture((char*)vo1.ref_voit);
}


void
on_button_retour_rech_voiture_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rech_voiture, *fenetre_voiture;

fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));
rech_voiture=lookup_widget(GTK_WIDGET(objet),("rech_voiture"));

gtk_widget_destroy(rech_voiture);
fenetre_voiture=create_fenetre_voiture();
gtk_widget_show(fenetre_voiture);
}


void
on_button_rech_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
voiture p;
GtkWidget *jr=lookup_widget(GTK_WIDGET(objet),"spin_voiture_j");
GtkWidget *ms=lookup_widget(GTK_WIDGET(objet),"spin_voiture_m");
GtkWidget *an=lookup_widget(GTK_WIDGET(objet),"spin_voiture_a");

GtkWidget *combobox_marque_voiture=lookup_widget(GTK_WIDGET(objet),"combo_marque");

p.dtvo.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
p.dtvo.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
p.dtvo.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

strcpy(p.marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_marque_voiture)));

char r1[20];
char r2[20];
char r3[20];
char dt_aller[20]="";


sprintf(r1,"%d",p.dtvo.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",p.dtvo.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",p.dtvo.annee);
strcat(dt_aller,r3);

chercher_voiture((char *)p.marque/*,(char *)c.arrivee,(char *)dt_aller,(char *)c.classe*/ );

GtkWidget *rech_voiture=lookup_widget(GTK_WIDGET(objet),"rech_voiture");
GtkWidget *treeview_rech_voiture;

treeview_rech_voiture=lookup_widget(rech_voiture,"treeview_rech_voiture");

afficher_rech_voiture(treeview_rech_voiture);
gtk_widget_show(treeview_rech_voiture);
}


void
on_treeview_reser_voiture_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(vo2.ref_voit,str_data);
}


void
on_button_supp_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
supprimer_voiture((char *)vo2.ref_voit);
/*****Actualiser lil liste **************/
GtkWidget *affich_reser_voiture=lookup_widget(GTK_WIDGET(objet),"affich_reser_voiture");
GtkWidget *treeview_reser_voiture;

treeview_reser_voiture=lookup_widget(affich_reser_voiture,"treeview_reser_voiture");

afficher_reser_voiture(treeview_reser_voiture);
gtk_widget_show(treeview_reser_voiture);

GtkWidget *Notification3;
Notification3=lookup_widget(GTK_WIDGET(objet),("Notification3"));
Notification3=create_Notification3();
gtk_widget_show(Notification3);
}


void
on_button_modif_voiture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
supprimer_voiture((char *)vo2.ref_voit);

GtkWidget *affich_reser_voiture, *rech_voiture;

rech_voiture=lookup_widget(GTK_WIDGET(objet),("rech_voiture"));
affich_reser_voiture=lookup_widget(GTK_WIDGET(objet),("affich_reser_voiture"));

gtk_widget_destroy(affich_reser_voiture);
rech_voiture=create_rech_voiture();
gtk_widget_show(rech_voiture);

}


void
on_button_retour_affich_voiture_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affich_reser_voiture, *fenetre_voiture;

fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));
affich_reser_voiture=lookup_widget(GTK_WIDGET(objet),("affich_reser_voiture"));

gtk_widget_destroy(affich_reser_voiture);
fenetre_voiture=create_fenetre_voiture();
gtk_widget_show(fenetre_voiture);
}


void
on_button_menu_voiture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_client, *fenetre_voiture;

menu_client=lookup_widget(GTK_WIDGET(objet),("menu_client"));
fenetre_voiture=lookup_widget(GTK_WIDGET(objet),("fenetre_voiture"));

gtk_widget_destroy(menu_client);
fenetre_voiture=create_fenetre_voiture();
gtk_widget_show(fenetre_voiture);
}
/******** gama****************/

void
on_closebutton1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification1;
Notification1=lookup_widget(GTK_WIDGET(objet),("Notification1"));
gtk_widget_destroy(Notification1);

}


void
on_closebutton2_activate               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification2;
Notification2=lookup_widget(GTK_WIDGET(objet),("Notification2"));
gtk_widget_destroy(Notification2);
}


void
on_closebutton3_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Notification3;
Notification3=lookup_widget(GTK_WIDGET(objet),("Notification3"));
gtk_widget_destroy(Notification3);
}

